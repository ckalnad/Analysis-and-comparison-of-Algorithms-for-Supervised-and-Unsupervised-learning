Pledge:
On my honor I have neither given nor received aid on this
exam.

Contents-
The folder source_codes includes all the MATLAB codes for part 1-5. I have named it accordingly.
The folder support_vector sets contains the support vectors for svm (linear and rbf)
The file results_takehome2 contains the report containing results.