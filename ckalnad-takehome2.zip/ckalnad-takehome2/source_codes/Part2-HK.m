clear
clc
close all
clearvars;
load train_case_1.dat
data_matrix = train_case_1;
fir_sec_10000_data = data_matrix(1:10000,1:4);

wt=[1 1 1 1];
fir_5000 = ones(5000,1);
sec_5000 = fir_5000*-1;
total = [fir_5000;sec_5000];
decision = [];
pos=[1];
neg=[-1];
zer=[0];
for iii = 1:10000
    if(wt*(fir_sec_10000_data(iii,:)')-1>0)
        %fprintf("w1\n");
        decision=[decision;neg];
    elseif((wt*fir_sec_10000_data(iii,:)')-1<0)
        %fprintf("w2\n");
        decision=[decision;pos];
    else
        %fprintf("line\n");
        decision=[decision;zer];
    end
end

confusion_matrix =  confusionmat(total,decision);

decision_2=[];
load test_case_1.dat;
test_case1_data = test_case_1;
fir_sec_10000_data_2 = test_case1_data(1:10000,1:4);        
for iii = 1:10000
    if(wt*(fir_sec_10000_data_2(iii,:)')-1>0)
        %fprintf("w1\n");
        decision_2=[decision_2;neg];
    elseif((wt*fir_sec_10000_data_2(iii,:)')-1<0)
        %fprintf("w2\n");
        decision_2=[decision_2;pos];
    else
        %fprintf("line\n");
        decision_2=[decision_2;zer];
    end
end   

confusion_matrix_2 =  confusionmat(total,decision_2);


clear
clc
close all
load train_case_1.dat
data_matrix = train_case_1;
w1 = data_matrix(1:5000,1:4);
w2 = data_matrix(5001:10000,1:4);
load test_case_1.dat;
data_matrix_2 = test_case_1;
test_data = data_matrix_2(1:15000,1:4);

ee=1;
true_test1 = [2;3;1;3;1;2];

for iu = 1:2500
    true_test_12(ee,1)=true_test1(1,1);
    true_test_12(ee+1,1)=true_test1(2,1);
    true_test_12(ee+2,1)=true_test1(3,1);
    true_test_12(ee+3,1)=true_test1(4,1);
    true_test_12(ee+4,1)=true_test1(5,1);
    true_test_12(ee+5,1)=true_test1(6,1);
    ee=ee+6;
end

%one=0;
%two=0;
%for tvt = 1:15000
    %if(true_test_12(tvt,1) == 1)
       % one=one+1;
    %elseif(true_test_12(tvt,1) == 2)
     %   two=two+1
    %end
%end
%fprintf(one)
%fprintf(two)


w3=[];
w4=[];
for ttt = 1:15000
    if(true_test_12(ttt,1) == 1)
        w3 = [w3;test_data(ttt,:)];
    elseif(true_test_12(ttt,1) == 2)
        w4 = [w4;test_data(ttt,:)];
    end
end
    
w1 = augment(w1);
w2 = augment(w2);
w3 = augment(w3);
w4 = augment(w4);

n = length(w1);
tr1 = w1;
tr2 = -1* w2;
test1 = w3;
test2 = -1* w4;

training = [tr1 ; tr2];

[a,b] = ho(training);

fprintf("Value of hyperplane parameter is\n")
disp(a)


disp('Ho-Kashyap results')
test(test1,test2,a)


a = ssp(training);


disp('Perceptron results')
test(test1,test2,a)                             %change this for testing train/test data


function [a,b] = ho(Y)
    [m,d] = size(Y);
    a = ones(d,1);
    b = ones(m,1);
    n = 1;
    k_max = 15000;
    k = 0;
    
    
    while k<k_max
        e = Y*a - b;
        b = b + n*(e+abs(e));
        a = pinv(Y)*b; 
        
        if abs(e)<0
            disp('not lin sep')
        elseif abs(e) < 0.01
            disp('done')
            disp(k)
            break;    
        end
                
        if k >= k_max
            disp('max iterations reached')
        end
        k = k+1;
        
    end
  
end


function test(w1,w2,a)
true_positive1 = 0;
true_negative1 = 0;
false_positive1 = 0;
false_negativen1 = 0;

true_positive2 = 0;
true_negative2 = 0;
false_positive2 = 0;
false_negative2 = 0;

    for i=1:length(w1)
        sample = w1(i,:);
        if dot(sample,a) >= 0 
            true_positive1 = true_positive1+ 1;
            true_negative2 = true_negative2+ 1;
        else
            false_negativen1 = false_negativen1 + 1;
            false_positive2 = false_positive2 + 1;
        end
        
    end
    
    for i=1:length(w2)
        sample = w2(i,:);
        if dot(sample,a) <= 0 
            true_positive2 = true_positive2+ 1;
            true_negative1 = true_negative1+ 1;
        else
            false_negative2 = false_negative2 + 1;
            false_positive1 = false_positive1 + 1;
        end
    end
    
    
disp('     tp    tn    fp    fn');
disp([false_positive1, false_negativen1, true_positive1, true_negative1]);
disp([false_positive2, false_negative2, true_positive2, true_negative2]);

end

function aug=augment(x)
    n= length(x);
    aug = [ones(n,1) x];
end


function a=ssp(samples)
    [n,d] = size(samples);
    a = zeros(d,1)';
    learning_rate = 1;
    correct = 0;
    while(correct < n)
        for i=1:n
            sample = samples(i,:);
            prediction = dot(a,sample);
            if prediction<=0
                a = a + learning_rate*sample;          
            else
                correct = correct + 1;
            end        
        end
    end
    

end


