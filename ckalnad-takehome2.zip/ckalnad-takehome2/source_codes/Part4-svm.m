clear
clc
close all

load train_case_1.dat
data_matrix = train_case_1(1:10000,1:4);
first_5000 = ones(5000,1);
second_5000 = first_5000*-1;
classes=[first_5000;second_5000];
load test_case_1.dat;
data_matrix_2 = test_case_1;
test_data = data_matrix_2(1:15000,1:4);
%Mdl = fitclinear(data_matrix,classes)
%Mdl2 = fitcecoc(data_matrix,classes)
Mdl = fitcsvm(data_matrix,classes,'KernelFunction','linear','Standardize',true);
Mdl2 = fitcsvm(data_matrix,classes,'KernelFunction','rbf','Standardize',true);

ee=1;
true_test1 = [2;3;1;3;1;2];

for iu = 1:2500
    true_test_12(ee,1)=true_test1(1,1);
    true_test_12(ee+1,1)=true_test1(2,1);
    true_test_12(ee+2,1)=true_test1(3,1);
    true_test_12(ee+3,1)=true_test1(4,1);
    true_test_12(ee+4,1)=true_test1(5,1);
    true_test_12(ee+5,1)=true_test1(6,1);
    ee=ee+6;
end

w3=[];
w4=[];
for ttt = 1:15000
    if(true_test_12(ttt,1) == 1)
        w3 = [w3;test_data(ttt,:)];
    elseif(true_test_12(ttt,1) == 2)
        w4 = [w4;test_data(ttt,:)];
    end
end

St=[w3;w4];

linear_predict = predict(Mdl,St);
rbf_predict = predict(Mdl2,St);

confusion_linear = confusionmat(classes,linear_predict);
confusion_rbf = confusionmat(classes,rbf_predict);

m_linear = margin(Mdl,St,classes);
m_rbf = margin(Mdl2,St,classes);

e_linear = edge(Mdl,St,classes);
e_rbf = edge(Mdl2,St,classes);

w1_linear = dot(Mdl.Alpha, Mdl.SupportVectors(:,1));
w2_linear = dot(Mdl.Alpha, Mdl.SupportVectors(:,2));
bias_linear = Mdl.Bias;

% y = a*x + b
a_linear = -w1_linear/w2_linear;
b_linear = -Mdl.Bias/w2_linear;

w1_rbf = dot(Mdl2.Alpha, Mdl2.SupportVectors(:,1));
w2_rbf = dot(Mdl2.Alpha, Mdl2.SupportVectors(:,2));
bias_rbf = Mdl2.Bias;

% y = a*x + b
a_rbf = -w1_rbf/w2_rbf;
b_rbf = -Mdl2.Bias/w2_rbf;

CVMdl = crossval(Mdl);
misclass_linear = kfoldLoss(CVMdl);

CVMdl2 = crossval(Mdl2);
misclass1_rbf = kfoldLoss(CVMdl2);
