clear
clc
close all


load train_case_1.dat;
load test_case_1.dat;

train_data = train_case_1;
test_data = test_case_1;

train_data_count = size(train_data,1);
test_data_count = size(test_data,1);

k=1;

for sample=1:test_data_count

  
   R = repmat(test_data(sample,:),train_data_count,1) ;
   edistance  = (R(:,1) - train_data(:,1)).^2;

 
    [dist position] = sort(edistance,'ascend');
    knearestneighbors=position(1:k);
    knearestdistances=dist(1:k);


   
    for i=1:k
        A(i) = train_data(knearestneighbors(i),2);  
    end

    M = mode(A);

    if (M~=1)
        test_data(sample,2) = mode(A);
    else 
        test_data(sample,2) = tr_data(knearestneighbors(1),2);
    end
end

ee=1;
true_test1 = [2;3;1;3;1;2];

for iu = 1:2500
    true_test_12(ee,1)=true_test1(1,1);
    true_test_12(ee+1,1)=true_test1(2,1);
    true_test_12(ee+2,1)=true_test1(3,1);
    true_test_12(ee+3,1)=true_test1(4,1);
    true_test_12(ee+4,1)=true_test1(5,1);
    true_test_12(ee+5,1)=true_test1(6,1);
    ee=ee+6;
end

first_5000 = ones(5000,1);
second_5000 = first_5000*2;
third_5000 = first_5000*3;
classes = [first_5000;second_5000;third_5000];
train_set = [train_data,classes];
test_set = [test_data,true_test_12];

Mdl = fitcknn(train_data,classes,'NumNeighbors',1,'Standardize',1);
class_test = predict(Mdl, test_data);

confusion_matrix = confusionmat(true_test_12,class_test)

Mdl2 = fitcknn(train_data,classes,'NumNeighbors',2,'Standardize',1);
class_test2 = predict(Mdl2, test_data);

confusion_matrix2 = confusionmat(true_test_12,class_test2)

Mdl3 = fitcknn(train_data,classes,'NumNeighbors',3,'Standardize',1);
class_test3 = predict(Mdl3, test_data);

confusion_matrix3 = confusionmat(true_test_12,class_test3)


