clear
clc
close all

load train_case_1.dat
data_matrix = train_case_1;
first_5000 = ones(5000,1);
second_5000 = first_5000*2;
third_5000 = first_5000*3;
classes = [first_5000;second_5000;third_5000];
dt = [data_matrix,classes];

data_matrix_1=data_matrix(1:5000,1:4);
data_matrix_2=data_matrix(5001:10000,1:4);
data_matrix_3=data_matrix(10001:15000,1:4);

mean_1 = mean(data_matrix_1);
mean_2 = mean(data_matrix_2);
mean_3 = mean(data_matrix_3);

c = 2;
metric = @manhattan;
X = data_matrix(1:15000,  1:4);
m = 1.5;
Max = 100000;
tol = 1e-3;

[nr nc] = size(X);
for i = 1:nc
   for j = 1:nr
     data(j, i) = (X(j, i)-std(X(:, i)))/mean(X(:, i));
   end
end



[prediction,v] = fcm(c, data, m, metric, Max, tol);
prediction_c_2 = (prediction)';
confusion_c_2 = confusionmat(classes,prediction_c_2);

a11 = unique(prediction_c_2);
out2 = [a11,histc(prediction_c_2(:),a11)];

c = 3;
metric = @manhattan;
X = data_matrix(1:15000,  1:4);
m = 1.5;
Max = 100000;
tol = 1e-3;

[nr nc] = size(X);
for i = 1:nc
   for j = 1:nr
     data(j, i) = (X(j, i)-std(X(:, i)))/mean(X(:, i));
   end
end

[prediction,v] = fcm(c, data, m, metric, Max, tol);
prediction_c_3 = (prediction)';
confusion_c_3 = confusionmat(classes,prediction_c_3);

b11 = unique(prediction_c_3);
out3 = [b11,histc(prediction_c_3(:),b11)];

dm1=[];
dm2=[];
dm3=[];

for pred = 1:15000
    if(prediction_c_3(pred,1) == 1)
        dm1 = [dm1;data_matrix(pred,1:4)];
    elseif(prediction_c_3(pred,1) == 2)
        dm2 = [dm2;data_matrix(pred,1:4)];
    elseif(prediction_c_3(pred,1) == 3)
        dm3 = [dm3;data_matrix(pred,1:4)];
    end 
end

dm1_mean = mean(dm1);
dm2_mean = mean(dm2);
dm3_mean = mean(dm3);

c = 4;
metric = @manhattan;
X = data_matrix(1:15000,  1:4);
m = 1.5;
Max = 100000;
tol = 1e-3;

[nr nc] = size(X);
for i = 1:nc
   for j = 1:nr
     data(j, i) = (X(j, i)-std(X(:, i)))/mean(X(:, i));
   end
end

[prediction,v] = fcm(c, data, m, metric, Max, tol);
prediction_c_4 = (prediction)';
confusion_c_4 = confusionmat(classes,prediction_c_4);

c11 = unique(prediction_c_4);
out4 = [c11,histc(prediction_c_4(:),c11)];


c = 5;
metric = @manhattan;
X = data_matrix(1:15000,  1:4);
m = 1.5;
Max = 100000;
tol = 1e-3;

[nr nc] = size(X);
for i = 1:nc
   for j = 1:nr
     data(j, i) = (X(j, i)-std(X(:, i)))/mean(X(:, i));
   end
end

[prediction,v] = fcm(c, data, m, metric, Max, tol);
prediction_c_5 = (prediction)';
confusion_c_5 = confusionmat(classes,prediction_c_5);

d11 = unique(prediction_c_5);
out5 = [d11,histc(prediction_c_5(:),d11)];

function [prediction v] = fcm(c, X, m, metric, Max, tol)
[n, no] = size(X);
U = zeros([c, n]);
v = repmat(max(X), c, 1).*rand([c, no]);
U = rand([c, n]);

for j = 1:n
      U(:, j) = U(:, j)./sum(U(:, j));      
end  

for i = 1:c
      v(i, :) = sum((X(:, :).*repmat(U(i, :)'.^m, 1, no)),1)./sum(U(i, :).^m);
end

v_old = v;
delta = 1e4;
k = 0;
while  (k<Max & delta>tol)
    for i = 1:c
      for j = 1:n
        U(i, j) = 1/sum((metric(X(j, :), v(i, :))./metric(X(j, :), v)).^(2/(m-1)));
      end
    end
    for i = 1:c
       v(i, :) = sum((X(:, :).*repmat(U(i, :)'.^m, 1, no)), 1)./sum(U(i, :).^m);  
    end
v_new = v;
delta = max(max(abs(v_new-v_old)));
v_old = v;

k = k+1;
end
prediction = zeros([1, n]);
for i = 1:n
   [M, prediction(i)]=max(U(:, i));
end

end

function [d] = manhattan(x, Y)
          d = sum(abs(bsxfun(@minus,x,Y)),2);
end
